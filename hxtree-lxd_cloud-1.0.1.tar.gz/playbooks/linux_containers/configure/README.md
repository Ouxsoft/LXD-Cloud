Server configuration is separate task from provisioning. 
Only after a server is provisioned it can be configured.
The main playbook.yaml in this directory is designed as the default configuration.
Additional sub "per service" playbooks are encouraged.
