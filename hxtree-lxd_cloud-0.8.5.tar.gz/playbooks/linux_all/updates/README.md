This script is designed to make updating machines easier by
iterating through a list of hosts.


