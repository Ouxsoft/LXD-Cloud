After a server is provisioned it can be configured.
Server configuration is separate task from provisioning. 

The main playbook.yaml in this directory is designed as the default configuration.

Additional sub "per service" playbooks are encouraged.
