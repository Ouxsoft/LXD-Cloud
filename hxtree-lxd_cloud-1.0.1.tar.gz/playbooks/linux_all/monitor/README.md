This module makes use of 

https://galaxy.ansible.com/zauberpony/mysql-query  / https://github.com/zauberpony/ansible-mysql-query

To install:

```apt install python-mysqldb```

```ansible-galaxy install zauberpony.mysql-query --force```
