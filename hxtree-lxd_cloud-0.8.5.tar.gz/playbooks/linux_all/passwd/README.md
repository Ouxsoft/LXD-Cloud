This playbook updates the SSH user password
